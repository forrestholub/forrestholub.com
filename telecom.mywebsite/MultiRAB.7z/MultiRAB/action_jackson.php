<?php 

echo $_GET['delay_sec_PHP'];

$delay_time = $_GET['delay_sec_PHP'];

echo "this is the variable set: ",  $delay_time;

?>

<?php
$page = $_SERVER['PHP_SELF'];
header("Refresh: $delay_time; url=$page");
?>

<h1>counter</h1>
<p> Your delay time is:<?php echo $delay_time; ?>  <br> </p>
<body>
            <h1 style="text-align:left">Random Image Factory</h1>
        <div class="item">
            <img src="vance_bridge_homepage_50kb.JPG">
        </div>
</body>
