'use strict';

const delay = document.getElementById("delay_sec");
console.log("Delay is:", delay);

function calc(){
    var delayedID = document.getElementById("delay_sec").value;
    var delayedName = document.getElementsByName("delay_sec_javascript").value;

    console.log("Delay using ID is:", delayedID);
    console.log("Delay using Name is:", delayedName);
}