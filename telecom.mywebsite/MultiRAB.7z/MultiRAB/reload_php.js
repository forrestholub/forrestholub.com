'use strict';

function loader(delay) {
    let counter = 1;
    let interval = delay;
    console.log(delay);
    console.log(counter);
    setInterval(() => {
        document.querySelector('h1').innerText = counter;
        counter++;
        if (counter > delay) location.reload();
    }, 1000);

}
