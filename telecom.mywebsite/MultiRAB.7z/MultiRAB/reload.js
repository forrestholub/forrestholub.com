'use strict';
// Defaults:
// Set delay_sec = 5
// Set repeat totals = 100 

    let counter = 1;

    setInterval(() => {
        document.querySelector('h1').innerText = counter;
        counter++;
        if (counter > 5) location.reload();
    }, 1000);




// function gotobasicwebsite(){
    // var delay_sec = document.forms.Multi_RAB.delay_sec.value
    // var repeat = document.forms.Multi_RAB.repeat.value
    // var delay_sec_mili = (delay_sec * 1000)
    // for (i = 0; i < repeat; i++) {
        // setTimeout(function (){window.open("www.google.com", "_blank");}, delay_sec_mili);
    // }
// }
// function websiteload(){
    // window.open("https://www.google.com", "_blank"); 
// }
// function gotobasicwebsite() {
    // var delay_sec = document.forms.Multi_RAB.delay_sec.value
    // var repeat = document.forms.Multi_RAB.repeat.value
    // var delay_sec_mili = (delay_sec * 1000)
    // for (var i = 0; i < repeat; i++) {
        // setInterval(websiteload, delay_sec_mili);
    // }
// }

// function gotobasicwebsite(){
    // setInterval(websiteload, 5000);
// }

